function loadPage(page) {
    fetch(page)
      .then(response => {
        if (!response.ok) throw new Error("Network error");
        return response.text();
      })
      .then(html => {
        const container = document.getElementById("main-content");
        container.innerHTML = html;
  
        // Manually handle script tags
        const scripts = container.querySelectorAll("script");
        scripts.forEach(script => {
          const newScript = document.createElement("script");
  
          if (script.src) {
            // Prevent duplicate loading
            if (![...document.scripts].some(s => s.src === script.src)) {
              newScript.src = script.src;
              newScript.async = false;
              document.body.appendChild(newScript);
            }
          } else {
            newScript.textContent = script.textContent;
            document.body.appendChild(newScript);
          }
  
          script.remove(); // optional
        });
      })
      .catch(err => {
        console.error("Failed to load page:", err);
        document.getElementById("main-content").innerHTML = `<p class="text-danger">Failed to load ${page}.</p>`;
      });
  }
  