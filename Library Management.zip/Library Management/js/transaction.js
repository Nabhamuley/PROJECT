const express = require('express');
const router = express.Router();
const db = require('../db'); // Assuming your database connection is in db.js

// Get all transactions (borrowed or returned)
router.get('/', (req, res) => {
  const query = 'SELECT * FROM transactions ORDER BY transaction_date DESC';

  db.query(query, (err, result) => {
    if (err) {
      console.error('Error fetching transactions:', err);
      return res.status(500).json({ message: 'Error fetching transactions' });
    }
    res.status(200).json(result);
  });
});

// Add a new transaction (borrow or return)
router.post('/', (req, res) => {
  const { user_id, book_id, transaction_type, transaction_date, due_date } = req.body;

  let status = '';
  if (transaction_type === 'borrow') {
    status = 'Borrowed';
  } else if (transaction_type === 'return') {
    status = 'Returned';
  }

  const query = `
    INSERT INTO transactions (user_id, book_id, transaction_type, transaction_date, due_date, status)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  const values = [user_id, book_id, transaction_type, transaction_date, due_date, status];

  db.query(query, values, (err, result) => {
    if (err) {
      console.error('Error processing transaction:', err);
      return res.status(500).json({ message: 'Error processing transaction' });
    }
    res.status(200).json({ message: 'Transaction successful' });
  });
});

module.exports = router;
